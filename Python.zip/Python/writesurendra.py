read = open('samnew.txt','r')
#write = open ('samnew1111.txt','w')
#print names_read
print read
for l in read:
    print "print line :",l
#print read
# write.write(l)