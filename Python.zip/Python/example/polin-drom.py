a=raw_input('enter a string')
b=list(a)
c=list(reversed(b))
if c==b:
   print 'is a polindrome'
else:
   print 'is not polindrome'
