squres={x: x*x for x in(6)}

print (squres)

add_squres={x:x*x for x in rangr(11)if x%2++1}
print add_squres