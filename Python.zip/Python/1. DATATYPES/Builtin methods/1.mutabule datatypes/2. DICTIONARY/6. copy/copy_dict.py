my_dict ={'name':'suri','Age':22}
my_dict1=my_dict.copy()
print my_dict1

aa=my_dict1               # deep copy in a dictionary

print "deep copy is ", aa
