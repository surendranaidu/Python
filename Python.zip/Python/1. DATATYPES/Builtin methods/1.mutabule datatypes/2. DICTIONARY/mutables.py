dict1={'name':'surendra','age':22, 'id':'e4'}
print dict1
print id(dict1)

dict={'name':'surendra','siva':'pass'}


dict1.update(dict)

print dict1
print id(dict)