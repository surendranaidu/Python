my_dict ={'name':'suri','Age':22,'eid':12345,'company':'Hcl'}

dict1={'address':'Atp','edu':'mba'}
my_dict.update(dict1)
print my_dict