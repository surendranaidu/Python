my_dict={1:1,2:4,3:9,4:16,5:25,6:36}

print len(my_dict)

print sorted(my_dict)
