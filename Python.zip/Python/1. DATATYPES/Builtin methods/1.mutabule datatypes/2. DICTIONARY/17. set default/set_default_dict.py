my_dict ={'name':'suri','Age':22,'eid':12345,'company':'Hcl'}

print my_dict.setdefault ('Age', 'none')
print my_dict.setdefault ('sex', 'none')
print my_dict.setdefault ('atm', 123)
