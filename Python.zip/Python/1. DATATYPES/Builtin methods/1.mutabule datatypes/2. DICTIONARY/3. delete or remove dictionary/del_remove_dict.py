squares_dict={1:1,2:4,3:9,4:16,5:25,6:36,7:49,8:64,9:81,10:100}

print squares_dict.popitem()
print squares_dict.pop(6)
squares_dict.clear()
print squares_dict
del squares_dict
print squares_dict