haskey_dict ={'name':'suri','Age':22}
print haskey_dict.has_key('Age')
print haskey_dict.has_key('eid')

