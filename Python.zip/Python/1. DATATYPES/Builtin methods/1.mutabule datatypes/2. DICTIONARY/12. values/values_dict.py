my_dict ={'name':'suri','Age':22,'eid':12345,'company':'Hcl'}

print my_dict.values()



my_dict ={'Age':23,'Age':22,'eid':12345,'company':'Hcl'}
print my_dict.popitem()