my_dict ={'name':'suri','Age':22}

print my_dict
print my_dict.clear()