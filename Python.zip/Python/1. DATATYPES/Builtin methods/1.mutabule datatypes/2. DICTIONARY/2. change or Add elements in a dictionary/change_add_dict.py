my_dict ={'name':'suri','Age':22}

my_dict['Age']=21     #change values
print my_dict

my_dict['Address']= 'Ananthapur'

print my_dict