my_dict ={'name':'suri','Age':22}

print my_dict['name']
print my_dict['Age']
print my_dict