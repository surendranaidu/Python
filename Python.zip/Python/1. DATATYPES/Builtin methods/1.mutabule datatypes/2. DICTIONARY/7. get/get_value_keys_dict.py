my_dict ={'name':'suri','Age':22, 'Eid':'E4','Ecducation':'MBA'}

print my_dict.get('Age')
print my_dict.get('MBA')
