my_dict={1:1,2:4,3:9,4:16,5:25,6:36}
for i in my_dict:
    print (my_dict[i])


