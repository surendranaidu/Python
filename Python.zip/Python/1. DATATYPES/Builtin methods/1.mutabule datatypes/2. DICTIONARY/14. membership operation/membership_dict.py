my_dict={1:1,2:4,3:9,4:16,5:25,6:36}

print (1 in my_dict)
print (2 not in my_dict)
print (49 in my_dict)