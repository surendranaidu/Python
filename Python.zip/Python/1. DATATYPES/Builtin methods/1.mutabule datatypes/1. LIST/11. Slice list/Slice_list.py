my_list = ['p','r','o','b','e','r','n','z','m']
print my_list
print my_list[0]
print my_list[0:5]
print my_list[2:5]
print my_list[:-5]
print my_list[5:]    #  ending