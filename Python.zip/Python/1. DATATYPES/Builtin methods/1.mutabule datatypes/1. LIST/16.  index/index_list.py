# index-------------------->>

my_list = ['p','r','o','b','e']
print my_list
print
print my_list[0]
print
print my_list[4]
print 
print my_list[-1]
print my_list.index('o')
