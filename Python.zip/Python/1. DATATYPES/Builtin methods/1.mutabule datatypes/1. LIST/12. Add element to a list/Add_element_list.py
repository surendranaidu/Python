# add elements to a list-------->>>>

add=[1,2,3,4,5,6]
add[1] =10
print 'add a number is ',add
add[1:6] =[11,12,13,14,15,16]
print "--------->>",add
