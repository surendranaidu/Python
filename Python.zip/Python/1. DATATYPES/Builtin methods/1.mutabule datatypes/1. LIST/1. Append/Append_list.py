
#  Append------------------------>>>>>

s_list =[1,2,3,4,5]
s_list.append(6)
print s_list

s_list1=["surendra"]
s_list1.append("chowdary")
print s_list1
