#  Extend------------------------->>>>>>

p_list=['suri',1,2,3,4,5]
p_list.extend([5,6,7,8,9,10])
print"------>>>", p_list
