'''L=[1,2,3,4]
l=[4,3,2,1]
print L+l[::-1]
L ="SRUE"
print L[::-1]


import calendar
#year=2016
#month=6
print calendar.calendar(2016)

#print cal


print calendar.isleap(2008)
print calendar.isleap(2009)
print calendar.isleap(2010)
print calendar.isleap(2011)'''

for i in range(1,16):
    print i
    for j in range (1,11):
        print i,'x',j,'=',i*j