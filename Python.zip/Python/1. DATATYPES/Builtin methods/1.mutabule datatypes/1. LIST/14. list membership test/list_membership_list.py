my_list = ['p','r','o','b','l','e','m']
print ('p' in my_list)
print ('a' in my_list)
print ('c'not in my_list)