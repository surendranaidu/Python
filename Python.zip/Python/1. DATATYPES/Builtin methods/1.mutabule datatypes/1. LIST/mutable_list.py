l = [1,2,3,4]
print 'one:',l, id(l)

l.append(5)

print 'one :', l, id(l)

#--------------------------

l = [1,2,3]

print 'two -', id(l)

l.append(5)
print 'two -', l , id(l)
