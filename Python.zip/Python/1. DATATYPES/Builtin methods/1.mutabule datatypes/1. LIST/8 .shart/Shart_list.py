#  sort ---------------------------->>>>>>>>>>
my_list =[3,8,1,6,0,8,4]
my_list.sort()
print my_list
