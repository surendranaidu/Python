# count --------------------------->>>>>>>>

my_list =[3,8,1,6,0,8,4]

print "count is -->>", my_list.count(8)
