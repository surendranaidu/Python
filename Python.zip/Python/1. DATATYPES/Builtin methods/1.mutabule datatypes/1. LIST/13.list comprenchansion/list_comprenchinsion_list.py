pow2= [2** x for x in range (10)]
print pow2