# reverse --------------------------->>>>>>>>>>>

my_list1 = ["a","r","d","n","e","r","u","s"]
my_list1.reverse()
print my_list1
