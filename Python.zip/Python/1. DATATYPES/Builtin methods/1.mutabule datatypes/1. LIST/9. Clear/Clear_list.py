# clear ----------------------------->>>>>>>>>>>>>

my_list12 = ["a","r","d","n","e","r","u","s"]
my_list12.clear()

print my_list12
