# insert -------------------------->>>>>>>

odd = [1, 9]
odd.insert(1,3)
print(odd)

odd[1:2] = [5, 7]

print(odd)
