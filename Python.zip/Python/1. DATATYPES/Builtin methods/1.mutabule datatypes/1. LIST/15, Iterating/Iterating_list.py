for fruit in ['Apple','Bannana','Mango']:
    print 'I like',fruit