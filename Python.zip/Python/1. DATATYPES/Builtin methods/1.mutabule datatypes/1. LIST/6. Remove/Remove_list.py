# remove ---------------------------->>>>>>>>>>>>

my_list1 = ["a","r","d","n","e","r","u","s"]
my_list1.remove("a")
print "remove ----.... 'a'",my_list1
