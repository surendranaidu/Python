# Nested List ,[index ]-------->>>

n_list = ["Happy", [2,0,1,5]]

print n_list[0][1] 

print n_list[1][3]
