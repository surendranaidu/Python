my_set ={1,2,3,4,5,6}
print my_set

my_set.discard(4)
print my_set
my_set.remove(3)
print my_set
my_set.discard(2)
print my_set