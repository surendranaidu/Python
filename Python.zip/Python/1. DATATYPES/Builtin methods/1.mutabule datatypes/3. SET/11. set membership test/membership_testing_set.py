my_set= set('Apple')
print ('A' in  my_set)
print ('b' in  my_set)
print ('z' not in my_set)