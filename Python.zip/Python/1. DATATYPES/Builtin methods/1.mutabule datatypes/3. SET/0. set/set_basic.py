my_set ={1,2,3,4,5,6,7,8,9}

print my_set

my_set={1.0,'Hello',(1,2,3,4,5)}
print my_set