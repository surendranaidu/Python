my_set={'suri','naidu'}
print my_set.pop()
print type(my_set)