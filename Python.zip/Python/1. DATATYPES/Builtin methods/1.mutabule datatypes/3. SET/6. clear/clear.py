my_set ={'suri','naidu',(1,2,3,4)}
print my_set.clear()