my_set ={1,3}
print my_set
my_set.add(2)
print my_set

#update------------>>>>>>>>>>

my_set.update([2,3,4])
print my_set

my_set.update([4,5],{1,6,8})
print my_set