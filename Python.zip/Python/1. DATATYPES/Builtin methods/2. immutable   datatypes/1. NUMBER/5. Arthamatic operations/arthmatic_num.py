
#'''Arthamatic operations'''
a=10
b=21
print "sum of a and b",a+b
print "sub of a and b",a-b
print "div of a and b",a%b
print "multifaction of a and b",a*b
print "mudales of a and b",a/b
print "squre of a and b",a**b
print " of a and b",a//b
