####  compration operations""""""""""""

a=9
b=10
print a==b
#print a=b
#print a:=b
print a<b
print a>b
print a<=b
print a>=b
