#folt
a1= 0.00
print int(a1)
print type(a1)
