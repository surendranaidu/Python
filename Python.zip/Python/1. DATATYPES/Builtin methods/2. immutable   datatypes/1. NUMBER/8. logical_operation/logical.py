# and *****************

a=12
b=11
print "and is", a and b
print "and is", a & b
print "and is", a != b


# or

p=12
q=11
print p or q


# not 

m=12
n=12
print m != n
