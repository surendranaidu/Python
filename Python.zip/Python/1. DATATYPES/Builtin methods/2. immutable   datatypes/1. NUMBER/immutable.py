n= 1,2,3,4
print n
print id(n)
print n
print id(n)