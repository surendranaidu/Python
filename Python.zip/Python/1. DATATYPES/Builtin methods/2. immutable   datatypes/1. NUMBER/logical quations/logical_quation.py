lists = [[]] * 3
print  lists
liats=[[], [], []]
lists[0].append(3)
print lists


list =[] for i in range(3):
list.append(2)
list.append(5)
list.append(6)
print list
