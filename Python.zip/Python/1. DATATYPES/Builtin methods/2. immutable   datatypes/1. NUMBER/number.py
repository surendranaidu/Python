# int 
a=10
print a

#folt
a1= 0.00
print int(a1)
print type(a1)

# LONG 
a=122222222
print a

#complex

a= 3.14j
print a


#'''Arthamatic operations'''
a=10
b=21
print "sum of a and b",a+b
print "sub of a and b",a-b
print "div of a and b",a%b
print "multifaction of a and b",a*b
print "mudales of a and b",a/b
print "squre of a and b",a**b
print " of a and b",a//b


####  compration operations""""""""""""

a=9
b=10
print a==b
#print a=b
#print a:=b
print a<b
print a>b
print a<=b
print a>=b


###### Assinmunt #########

a = 3
b = 5
c = 0

c = a + b
print "Line 1 - Value of c is ", c

c += a
print "Line 2 - Value of c is ", c 

c *= a
print "Line 3 - Value of c is ", c 

c /= a 
print "Line 4 - Value of c is ", c 

c  = 2
c %= a
print "Line 5 - Value of c is ", c

c **= a
print "Line 6 - Value of c is ", c

c //= a
print "Line 7 - Value of c is ", c




# and *****************

a=12
b=11
print "and is", a and b
print "and is", a & b
#print "and is", a ! b


# or

p=12
q=11
print p or q


# not 

m=12
n=11
#print m not n







a='0'
b='2'
print a+b
print int(a)+int (b)


lists = [[]] * 3
print  lists
liats=[[], [], []]
lists[0].append(3)
print lists


list =([]  for i in range(3)):
list.append(2)
list.append(5)
list.append(6)
print list




