a='0'
b='2'
print a+b
print int(a)+int (b)


# siting convert


s= 'surendra'
p=22
print s+str(p)
print type(p)
