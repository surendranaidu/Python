# LONG 
a=122222222
print a
