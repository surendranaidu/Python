#index''''''''''''

str1 = "this is string example....wow!!!";
str2 = "exam";
str0="w"

print str1.index(str2)
print str1.index(str2, 9)
print str1.index(str0, )
