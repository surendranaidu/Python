
############# upper #################


str = "this is string example....ow!!! this is really string";
str2='Surendrachowdarey'
print str.isupper()
print str2.isupper()