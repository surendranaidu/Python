#*****SLICE OPERATION*******


slice = "i am surendra naidu atp"

print slice[2:]
print slice[:10]
print slice[1:16]


##### update****************

print slice+"Andhrapradesh"

print slice[:14]+"chowdary"

