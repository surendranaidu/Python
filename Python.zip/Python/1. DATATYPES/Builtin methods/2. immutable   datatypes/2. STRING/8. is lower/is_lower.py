
############# islower ,, is upper #################


str1 = "this is string example....ow!!! this is really string";
str='Surendrachowdarey'
print str1.islower()
print str.islower()
