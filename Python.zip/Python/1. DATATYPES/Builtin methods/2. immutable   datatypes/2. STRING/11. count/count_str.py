my_str ="i am surendra naidu is "
s="i"
print my_str.count(s) 
print my_str.count(s,11,20)
