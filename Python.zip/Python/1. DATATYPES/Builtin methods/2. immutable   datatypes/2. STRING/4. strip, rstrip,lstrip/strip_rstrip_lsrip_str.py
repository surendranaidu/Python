
#'''''''''''strip'''''''''''

a ="   surendra surendra re  "
print "strip is ------->>>>>>", a.strip()
print " rstrip is ----->>>>>>",a.rstrip()
print " rstrip is ----->>>>>",a.lstrip()
b=a.lstrip()
print[b]