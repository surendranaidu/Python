import time
import calendar
a=time.asctime()
time.sleep(3)
print "this is asctime", a

b=time.localtime()

time.sleep(3)
print "this is local time",b

c = calendar.calendar (2016)

time.sleep(3)
print "this is simple",c


f = calendar.calendar (2016,1,2,10)
time.sleep(4)
print "thiscal",f


d = calendar.leapdays(2016,2050)
print "this is leap days",d

e = calendar.isleap(2016)
print "this is leap days",e

