'''a = [2,-2,0,3,6,-55,7]
b = []
for i in range(len(a)):
    c = min(a)
    b.append(c)
    a.remove(c)
print b


a=[9,8,7,6,6,3,2,7,8,9]

for i in range(0,len(a)):
    print(a)'''



a= [2,1,3,68,1,8,9,11,10]
b= []
for i in range (len (a)):
    c=max(a)
    b.append(c)
    a.remove(c)
print b


f= [k,f,y,w,e,g,d,s,w,w,a,g,g,f,l]
v= []
for i in range (len (f)):
    m=max(f)
    v.append(m)
    v.remove(m)
print v