#find ;;;;;;;;;;;;;;

k= 'surendrsnaidu'
p='i'
c= 'bangalore'
m='g'
print "find is",k.find(p)
print 'find g is ',c.find(m,2,6)
