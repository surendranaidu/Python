#####join###################
a =''
b ='chowdary'
c= 'aa'
print "a sting join ",a.join(b),"c join in c ",b.join(c)
