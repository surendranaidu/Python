#replace..............

str = "this is string example....wow!!! this is really string";
print str.replace("is", "was")
print str.replace("is", "was",2 )
