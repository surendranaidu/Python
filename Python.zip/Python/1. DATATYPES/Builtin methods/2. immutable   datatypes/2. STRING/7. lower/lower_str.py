
############# islower ,, is upper #################


str = "this is string example....ow!!! this is really string";
str='Surendrachowdarey'
print str.lower()
print str.islower()