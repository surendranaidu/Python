
############# upper #################


str = "this is string example....ow!!! this is really string";
str2='Surendrachowdarey'
print str.upper()
print str2.isupper()