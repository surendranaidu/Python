a="surendra"
print a
print id(a)
c= a+"chowdary"
print c
print id(c)