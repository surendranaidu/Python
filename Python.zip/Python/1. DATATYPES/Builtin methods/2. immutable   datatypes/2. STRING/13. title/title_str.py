

#'''''''' title ''''''''
s= 'surendra naidu chowdary sv college'
print s.title()
