
# tuple index --------->>>>>

p=['r','t','j','t','k','l']
print p[0]
print p[-1]

#index---------------1


n_tuple = ("mouse", [8, 4, 6], (1, 2, 3))

# nested index
print n_tuple[0][3]

# nested index

print n_tuple[1][1]
print n_tuple[2][1]
#print dir(n_tuple)
#index--------------4

tuple_p =("a","p","p","l","e")
print"index a value tuple_p 'l'",tuple_p.index("l")

