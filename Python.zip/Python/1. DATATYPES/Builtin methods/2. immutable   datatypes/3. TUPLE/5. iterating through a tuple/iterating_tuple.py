#iterating throgh a tuple ------7

for name in ("suri","naidu","chowdary"):
    print ("hello" , name)



