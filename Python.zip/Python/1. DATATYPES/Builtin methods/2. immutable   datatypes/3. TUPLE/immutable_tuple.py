'''t=('surendra','naidu')
print t 
print id(t)
t[o][1]="chowdary"
print t
print id(t)'''


suri = (1,2,3,[6,5])
print suri
print id(suri)
suri[3][1]=10
print suri
print id(suri)
print type(suri)
