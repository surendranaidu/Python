#tuple---------->>>>>

a=('surensra','naidu')

print a[0]

#tuple multi---------->>>>

m=('suri',[1,2,3,4,5],('sri'))
print dir(m)
print m[1]

# tuple index --------->>>>>

p=['r','t','j','t','k','l']
print p[0]
print p[-1]

#index---------------1


n_tuple = ("mouse", [8, 4, 6], (1, 2, 3))

# nested index
# Output: 's'
print n_tuple[0][3]

# nested index
# Output: 4
print n_tuple[1][1]
print n_tuple[2][1]
print dir(n_tuple)

#'''''''''''''''''''''2

suri=(4,2,3, [6,5])
suri[3][1] = 10
print 'change value is -------3ye7e2uudg',(suri)


# we cannot change an element
# you will get an error:
# TypeError: 'tuple' object does not support item assignment

my_tuple = ('p','r','o','g','r','a','m','i','z')
print(my_tuple)

#count-------------3

suri=("a","p","p","l","e")
print "count p is ",suri.count("p") 

#index--------------4

tuple_p =("a","p","p","l","e")
print"index a value tuple_p 'l'",tuple_p.index("l")


#member ship operation -----------5

s_tuple =("suri", "ram", "narendra ","and","siva", "venky ","a", "b")

print "siva" in  s_tuple 
print "and" in  s_tuple 
print "a" in  s_tuple 
print "s"in  s_tuple 
print "d" not in s_tuple

#compared---------------6
s ,s1=(123,'abc'),(1114,'xyzs')
print cmp(s,s1)
print cmp(s1,s)
s2=s1+(786,)
print cmp (s2,s1)


#iterating throgh a tuple ------7

for name in ("suri","naidu","chowdary"):
    print ("hello" , name)

#--------tuple deleting

suri=('a','p','p','l','e')
del suri


