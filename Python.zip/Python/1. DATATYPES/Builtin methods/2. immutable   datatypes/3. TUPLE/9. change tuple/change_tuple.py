#'''''''''''''''''''''2

suri=(4,2,3, [6,5])
suri[3][1] = 10
print 'change value is ',(suri)
