# nexte tuple---------->>>>

m=('suri',[1,2,3,4,5],('sri'))

print m[1]
print m[2]
print dir(m)
print type(m)