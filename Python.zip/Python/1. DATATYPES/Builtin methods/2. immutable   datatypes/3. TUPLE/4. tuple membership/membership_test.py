#member ship operation -----------5

s_tuple =("suri", "ram", "narendra ","and","siva", "venky ","a", "b")

print "siva" in  s_tuple 
print "and" in  s_tuple 
print "a" in  s_tuple 
print "s"in  s_tuple 
print "d" not in s_tuple

