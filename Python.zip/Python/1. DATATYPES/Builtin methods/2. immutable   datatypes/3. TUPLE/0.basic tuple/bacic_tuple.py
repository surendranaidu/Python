my_tuple = ('p','r','o','g','r','a','m','i','z')
print(my_tuple)
