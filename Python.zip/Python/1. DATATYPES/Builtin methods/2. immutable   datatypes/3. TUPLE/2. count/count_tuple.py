#count-------------3

suri=("a","p","p","l","e")
print "count p is ",suri.count("p") 
