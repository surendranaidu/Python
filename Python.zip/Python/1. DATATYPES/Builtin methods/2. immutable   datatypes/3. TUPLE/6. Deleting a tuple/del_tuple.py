#--------tuple deleting

suri=('a','p','p','l','e')
del suri
