import MySQLdb
db= MySQLdb.connect('127.0.0.1','root','root','surendra')
cursor = db.cursor()
#cursor.execute('create table sunil(name char(24),surname char(20),age int(20),address varchar(20),state char(20),income float)')
sql=   """insert into sunil (name,surname,age,address,state,income)
          values("p","esukumar",23,"blg","karanataka",60000)"""
          
cursor.execute(sql)
db.commit()

#for row in cur.fetchall():
#print row[0]

db.close()


'''
