'''
import MySQLdb
db=MySQLdb.connect("127.0.0.1","root","root","pattipati")
cursor=db.cursor()
sql= """ insert into sukumar
         values
              ("surendranaidu","22","atp","20000"),
              ("suri","22","tdp","25000"),
              ("anil","22","hdp","22000"),
              ("siva","25","hdp","224578")"""
cursor.execute(sql)
db.commit()
db.close()
'''

#show table


import MySQLdb
db= MySQLdb.connect('127.0.0.1','root','root','pattipati')  #  show databsese not  databasesname , ''using table name databases''

cursor = db.cursor()
#cursor.execute('show databases') # databases show
#cursor.execute('show tables') #  show tables
cursor.execute('select *from sukumar') #  show table

db.close()

for row in cursor.fetchall():
    print row[0],row[1],row[2],row[3]


