import MySQLdb
db = MySQLdb.connect ("127.0.0.1","root","root","pattipati")
cursor = db.cursor()
#ursor.execute("DROP TABLE IF EXISTS SUKUMAR2)
a = """CREATE TABLE SUNIL(
         NAME CHAR(30),
         AGE INT(20),
         ADDRESS VARCHAR(20),
         INCOME INT(20))"""

b = """ INSERT INTO SUNIL  
        VALUES
           ("surendra",22,"ATPO",450),
           ("RAAAM",22,"uhsyhTPO",880000),
           ("s",22,"shdsjdATPO",20000),
           ("sundra",20,"ATPO",200),
           ("surdra",21,"jsjshhATPO",19000)"""
           
cursor.execute(a)
cursor.execute(b)
db.commit()
db.close()

select * from emp