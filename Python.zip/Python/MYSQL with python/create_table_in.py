import MySQLdb
db = MySQLdb.connect ("127.0.0.1","root","root","pattipati")
cursor=db.cursor()
cursor.execute("DROP TABLE IF EXISTS SUKUMAR")
sql = """CREATE TABLE SUKUMAR(
         NAME CHAR(30),
         AGE INT(20),
         ADDRESS VARCHAR(20),
         INCOME FLOAT)"""
cursor.execute(sql)
db.close()