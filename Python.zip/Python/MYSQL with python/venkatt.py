import MySQLdb

db = MySQLdb.connect("127.0.0.1","root","root","surendra")
cursor = db.cursor()
#cursor.execute("DROP TABLE IF EXISTS IBM")
sql = """ CREATE TABLE IBM(
         name char(20),
         sex char(20),
         eid varchar(20),
         esal int(10),
         age int(20),
         address varchar(20))"""
cursor.execute(sql)
#db.commit()

#for row in cur.fetchall():
 #   print row[0]

db.close()
