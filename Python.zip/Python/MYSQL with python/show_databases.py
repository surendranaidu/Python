import MySQLdb
db= MySQLdb.connect('127.0.0.1','root','root','surendra')  #  show databsese not  databasesname , ''using table name databases''

cursor = db.cursor()
#cursor.execute('show databases') # databases show
#cursor.execute('show tables') #  show tables
cursor.execute('select *from sunil') #  show table

db.close()

for row in cursor.fetchall():
    print row[0],row[1],row[2],row[3],row[4],row[5]


