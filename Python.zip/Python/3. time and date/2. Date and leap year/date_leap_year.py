import calendar

#print calendar.month(2016,6)


print calendar.calendar(2016)

print calendar.isleap(2008)
print 'dsfsf', calendar.isleap(2009)
print calendar.leapdays(2015,2021)
print calendar.monthrange(2016,12)
#print calendar.monthcalendar(self,2016,3)
print calendar.weekday(2016,11,30)

'''
import datetime
tday= datetime.date.today()
print tday.weekday()
print tday.isoweekday()

#print tday'''

