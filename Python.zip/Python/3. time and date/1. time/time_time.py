'''import time


#print "current time is ----->>>",time.asctime()
a=time.localtime()

print a

print 
time.sleep(4)
print "hello wolrd!"
#print time(str)
#print time.mktime(tuple)
print time.localtime[1]

import time
time.sleep(5)

a = 2
b = 4
print 'a+b is:', a+b

time.sleep(2)
c= 4
d = 5
print 'c+d value is :',c+d  '''

import time
time.sleep(5)
for i in range(1,11):
    print i*'2'