class Arithmetic():
    name = raw_input(' is name' )
    def __init__(self,a, b):
        self.a = a
        self.b = b  
        def add(self, a,b):
            print sel.a + self.b
        def sub(self, a,b):
            print a*b
        def div(self, a,b):
            print a/b
        def modulus(self, a,b):
            print a%b 
inst = Arithmetic(4,4)
inst.add(2,2)
#inst.sub(10,5)
#inat.div(97,3)
#inst.modulus(20,3)
print Arithmetic.name

class Arithmatic():
    name =raw_input('Before executing this code please enter yoyr good name : ')
    def __init__(self,a, b):
        self.a = a
        self.b = b

    def add(self,a, b):
        print ' a+b addition is :',a + b
    def sub(self,a, b):
        print 'a-b substraction is :',a - b
    def mul(self,a, b):
        print 'a*b multiplication is :',a * b
    def div(self,a, b):
        print 'a/b division is :',a / b
    def modulo(self,a, b):
        print 'a%b modulo is :',a % b 
inst = Arithmatic(100,200)     # what is the use of this (2,4) and i will give ().then what happen
inst.add(4,5)
inst.sub(8,2)
inst.mul(4,4)
inst.div(9,4)
inst.modulo(9,4)

print Arithmatic.name
