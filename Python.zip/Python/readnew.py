names_read = open('sample.py','r')
#name_read.write ("surendranaiddu","pa")
d=names_read 
print d
for line in names_read:
    print line
