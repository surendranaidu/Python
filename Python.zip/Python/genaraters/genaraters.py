def Surendra(n):
    for i in range(1,n):
        print i
        yield "mba", i
    yield "software engeneering in python"
ik.next()

for i in Surendra(10):
    print i
#next()
#g=Surendra()




def sure_next():
    #print i
    yield "suri"
    yield "venky'"
i=sure_next()
print next(i),next(i)
#print next(i) 

#print k
#n=i,next()
