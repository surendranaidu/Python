import threading

import time

def surendra():
    time.sleep(2)
    print threading.currentThread().getName(),"\nstarting --->>>surendra"
    def add():
        print 'sume is ', 10+20
    add()
    time.sleep(5)
    print threading.currentThread().getName(),"\nexite-------->>>surendra"
    
    try:
        class sukumar():
            time.sleep(3)
            print threading.currentThread().getName(),"\n second start sukumar----->>>"
            def __init__(self,a,b):
                self.a=a
                self.b=b
            def suri(self,a,b):
                print 'sukumar is sum is-->>',self.a + self.b
                print 'division is sukumar::--->',a*b
        inst=sukumar(10,20)
        inst.suri(10,5)
    except:
        print "ok"
    finally:
        time.sleep(6)
        print threading.currentThread().getName(),"\nexite-------->>>sukumar"

b = threading.Thread(name='surendrachowdary',target=surendra)
b.start()
k = threading.Thread(name='sukumar',target=sukumar)
k.srart()







'''
class sukumar():
    def __init__(self,a,b):
        self.a=a
        self.b.=b
    def suri(self,a,b):
        print 'sukumar is sum is-->>',self.a+self.b
        print 'division is sukumar::--->',a/b
inst=sukumar(10,20)
inst=suri(10,5)
time.sleep(5)
print threading.currentThread().getName(),"\nexite-------->>>surendra"
'''