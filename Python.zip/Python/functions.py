def add (a=10,b=34):
    print 'a values is :',a
    print 'b values is :',b
    print a+b

add()

def surendrainfo(name, age,id,company,hometown,salary):
    print 'emp name is --->', name
    print "emp age is --->",age
    print "emp id:",id
    print "emp company is:",company
    print "emp home town:",hometown
    print "emp salary is :", salary
surendrainfo("suri",23,32152,"igs","bng",52309)

def default(name, age=23,):
    print ' my name is----$:', name
    print ' age is ------>:', age 

default('surendra',25)  
default('SURI') 

def alldatatypes(name,numbe        
    print "my name is :",name
    print "my number:",number
    print "my id is:", id
    print "my id is:",id
alldatatypes("surendraddss",777,543  0    
