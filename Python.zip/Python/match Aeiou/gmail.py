'''import re

a='2323surendranaidu10@gmail.com'

b= re.findall(r'\w+\D\w+.\w*',a)
#b= re.findall(r'[a-z]+ \+',a )'\w+\D\w+.\w+',a)

print b
a = 24
print long(a)'''
def add(**keywordarg):
    print 'a+b',keywordarg
add(name='anjan',age=28)