'''a="aaasksjsiousdfghjklzxcvnmoutr"
b={}
for i in a:
    if i in "aeiou":
        b[i]=a.count(i)
print b,
'''


import re

a='2323surendranaidu10@gmail.com'
b= re.findall(r'\w+\D\w+.\w*',a)
#b= re.findall(r'[a-z]+ \+',a )'\w+\D\w+.\w+',a)
print b



rents = {"apartment": 1000, "house": 1300}

# Convert to list of tuples.
r = rents.items()

# Loop and display tuple items.
for r in rentItems:
    print("Place:", r[0])
    print("Cost:", rentItem[1])
    print("")

a={'a':12,'id':100}

r = a.items()

for r in aitems:
    print r[0]
    print aitems[1]