
a = zip([1,2,3,4,5],[9,8,7,6,5], ['a','b','c','d','e','f'])

print ' zip values are :', a

