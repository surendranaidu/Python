'''print map(lambda a,b:a+b*3,[1,2,3,4,5,], [10,20,30,40,50])
print map(lambda a,b:a*b,[1,2,3,4,5,], [10,20,30,40,50])

l=[1,2,3,4]
p=[5,4,3,2]
q=list(map(lambda a,b:a+b,l,p))
print (q)


print map(lambda a,b:a+b,[1,2,3,4,5,], [5,4,3,2,1])
print map(lambda a,b:a%b,[1,2,3,4,5,], [10,20,30,40,50])
print map(lambda a:a%2==0,[1,2,3,4,5,])
print map(lambda a:a%2,[1,2,3,4,5,6,7,8,9,10,11,12])

print map(lambda a:a/2==0,[1,2,3,4,5,6,7,8,9,10,11,12])

print filter(lambda a:a%2==0,[1,2,3,4,5,6,7,8,9,10,11,12])
print filter(lambda a:a%2,[1,2,3,4,5,6,7,8,9,10,11,12])
print filter(lambda a:a/9==0,[1,2,3,4,5,6,7,8,9,10,11,12])

l= lambda a,b:a+b 
print l(20,2)

print filter(lambda a,b:a+b,[1,2,3,4,5,6,7],[8,9,10,11,12,89,9])'''


'''a=[1,2,3,4,5]
b=[5,4,3,2,1]
print a+b

k = (lambda a,b:a+b,[1,2,3,4,5,], [5,4,3,2,1])'''

#print map(lambda a,b:a+b10,[1,2,3,4,5]



venk=[1,2,3,4,4,4,]
f=sum
print f






