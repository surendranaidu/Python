n=(1,2,3,4)
ss=sum(list(n))
print(s+1)




print 


rr=(1,2,3,4,5)
s=sum(list(rr))
print (s+11)
