def aa(a,b):
    return a+b 
print reduce(aa,range(1,11))
