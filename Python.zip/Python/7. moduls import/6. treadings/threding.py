
import threading
import time

def first():
    time.sleep(2)
    print  threading.currentThread().getName(), '\nfirst start'
    time.sleep(6)
    print '\nexit name', threading.currentThread().getName()



def second():
    time.sleep(3)
    print threading.currentThread().getName(),'\nsecond start'
    time.sleep(8)
    print threading.currentThread().getName(),'\nmy second _service exit is'

def second_thread():
    time.sleep(5)
    print threading.currentThread().getName(),'\nsecond_thread start'
    time.sleep(10)
    print threading.currentThread().getName(),'\nsecond_thred is'


#t = threading.Thread( name='sssss',target=second)

#w = threading.Thread(name='frist1', target=frist)

#a = threading.Thread(name='second_thread', target=second_thread)

w = threading.Thread(name='surendranaidu',target=first)

t = threading.Thread(target=second)



a = threading.Thread(target=second_thread)

#print 'dir is :', dir(w)

w.start()
t.start()
a.start()
#w2.start()

'''


import threading

def worker(num):
    # """thread worker function"""
    print 'Worker: %s'%num
    return

threads = []
for i in range(5):
    t = threading.Thread(target=worker, args=(i,))
    threads.append(t)
    t.start()



#add
import threading
import time
def surendra():
    time.sleep(5)
    print threading.currentThread().getName(), "\n----->>> surendra start"
    time.sleep(10)
    print threading.currentThread().getName(), "\n----->>> exit surendra"
    
    time.sleep(2)
    def Add(a,b):
        print "a is",a
        print "b is ",b

        print "sum Is",a+b
    Add(10,30)
a=threading.Thread(name="surendra",target=surendra)
a.start()
#-----------------------------

def do_this():
    print "this is our thread"

def main():
    oue_thread=threading.thread(target=do_this)
    our_thread.star()

    print threading.active_count()
    print threading.enumerate()
    print threading.current_Thread()
if ( __name__ == "__main__" ):
    main()
    


'''


'''
t = threading.Thread(target=my_service)
w = threading.Thread(name='worker', target=worker)
st = threading.Thread(name='second_thread', target=second_thread)

import threading
import time

def worker():
    print 'worker start'
    print 'thread name is :::::', threading.currentThread().getName()
    time.sleep(5)
    print 'worker exit is'


def my_service():
    print '\nmy service is'
    print 'thread name is :::::', threading.currentThread().getName()
    time.sleep(6)
    print 'my_service exit is'

def second_thread():
    print '\nsecond_thred is'


t = threading.Thread(target=my_service)
w = threading.Thread(name='worker', target=worker)
st = threading.Thread(name='second_thread', target=second_thread)

print 'dir is :', dir(t)


w.start()
t.start()
st.start()
#w2.start()
'''