import threading
import time
def surendra():
    time.sleep(12)
    print threading.currentThread().getName(), "\n----->>> surendra start"

def Add(a,b):
    time.sleep(2)
    print "a is",a
    print "b is ",b
    time.sleep(2)
    print "sum Is",a+b
    time.sleep(1)
    print threading.currentThread().getName(), "\n----->>> exit surendra"


a=threading.Thread(name="surendra",target=surendra)
a.start()

b=threading.Thread(name="surendra132",target=Add(3,4))
b.start()
