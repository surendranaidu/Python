import time


a=time.asctime()
print a