
import re


e1='surendra.suri10@gmail.in' 
e2='surendra111@yahoomail.net'
e3='sureensra.11@sdeered.edu'
e4='sureensra.@sdeered.gov'


obj=re.match(r'[\w.]+\d+@\w+\.(in|net|com|edu|gov)',e1)

print obj.group()



e5='surendra12_nai1111du@yahoo123.co.in'


obj=re.match(r'(\w+[.|\w])*@(\w+[.])*(in|net|com|edu|gov)',e5)
print obj.group()