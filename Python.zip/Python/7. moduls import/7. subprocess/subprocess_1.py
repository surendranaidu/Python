import subprocess
import os
 
 
proc = subprocess.Popen(["dir"], stdout=subprocess.PIPE, shell=True)
(out, err) = proc.communicate()
print "program output:", out
 
 

#ou = os.popen('dir').read()
 
#print 'ou is ', ou
 
 
#import subprocess
#@2import os
 
#batcmd="ps -aux|grep python|awk '{print $2}'"
#result = subprocess.check_output(batcmd, shell=True)
 
 
#print result