import subprocess
import os
 
batcmd="ps -aux|grep python|awk '{print $2}'"
result = subprocess.check_output(batcmd, shell=True)
 
 
print 'output is :', result