import os
print'import os getcwd is', os.getcwd()