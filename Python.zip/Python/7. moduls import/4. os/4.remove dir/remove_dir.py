import os
os.rmdir("D:\\surendra\Python\\7. moduls import\\4. os\\1. makedir\\surendra mkdir new")