import os

os.chdir('D:\\surendra')

print os.system('dir')