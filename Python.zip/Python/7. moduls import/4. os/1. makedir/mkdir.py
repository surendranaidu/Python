import os
os.mkdir('surendra mkdir new')