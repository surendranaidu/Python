import

a= "surendra"
print a
