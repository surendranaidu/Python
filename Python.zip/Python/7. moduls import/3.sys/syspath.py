import sys
sys.path.append('D:\\Desktop2\\surendra\\interview quation\\Even nuber')
import Even