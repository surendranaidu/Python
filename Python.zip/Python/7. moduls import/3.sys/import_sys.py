import sys
print ' arg[0] is:',sys.argv[0]
print ' arg[1] is:',sys.argv[1]
print ' arg[2] is:',sys.argv[2]




def add(a=sys.argv[1],b=sys.argv[2]):
    print 'a value is:',a
    print 'b value is:',b
    print 'a+b value is:',a+b
add()