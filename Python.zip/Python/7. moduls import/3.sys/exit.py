import sys
a= 'surendra'
print a

print "sur23345"
try:
    sys.exit(1)
except:
    pass

print "sururuu"

'''
# File: sys-exit-example-2.py

import sys

print "hello"

try:
    sys.exit(1)
except SystemExit:
    pass

print "there"
'''