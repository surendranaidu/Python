
# list ------------------->

list_p=["surendra",123,"siva","narendra"]

print"list is ---->>>" ,dir(list_p)

# index-------------------->>

my_list = ['p','r','o','b','e']
print my_list
print
print my_list[0]
print
print my_list[4]
print 
print my_list[-1]
print my_list.index('o')




# Nested List ,[index ]-------->>>

n_list = ["Happy", [2,0,1,5]]

print n_list[0][1] 

print n_list[1][3]

# add elements to a list-------->>>>

add=[1,2,3,4,5,6]
add[0] =10
print 'add a number is ',add
add[1:6] =[11,12,13,14,15,16]
print "--------->>",add

#  Append------------------------>>>>>

s_list =[1,2,3,4,5]
s_list.append(6)
print s_list

s_list1=["surendra"]
s_list1.append("chowdary")
print s_list1

#  Extend------------------------->>>>>>

p_list=['suri',1,2,3,4,5]
p_list.extend([5,6,7,8,9,10])
print"------>>>", p_list


# insert -------------------------->>>>>>>

odd = [1, 9]
odd.insert(1,3)
print(odd)

odd[1:2] = [5, 7]

print(odd)

# count --------------------------->>>>>>>>

my_list =[3,8,1,6,0,8,4]

print "count is -->>", my_list.count(8)


#  pop ----------------------------->>>>>>>>>

my_list =[3,8,1,6,0,8,4]
print my_list.pop()

#  sort ---------------------------->>>>>>>>>>
my_list =[3,8,1,6,0,8,4]
my_list.sort()
print my_list

# reverse --------------------------->>>>>>>>>>>

my_list1 = ["a","r","d","n","e","r","u","s"]
my_list1.reverse()
print my_list1


# remove ---------------------------->>>>>>>>>>>>

my_list1 = ["a","r","d","n","e","r","u","s"]
my_list1.remove("a")
print "remove ----.... 'a'",my_list1

# clear ----------------------------->>>>>>>>>>>>>

#my_list12 = ["a","r","d","n","e","r","u","s"]
#my_list12.clear()

#print my_list12


my_list = ['p','r','o','b','l','e','m']
my_list.remove('p')

# Output: ['r', 'o', 'b', 'l', 'e', 'm']
print(my_list)

# Output: 'o'
print(my_list.pop(1))

# Output: ['r', 'b', 'l', 'e', 'm']
print(my_list)

# Output: 'm'
print(my_list.pop())

# Output: ['r', 'b', 'l', 'e']
print(my_list)

#my_list.clear()

# Output: []
print(my_list)



# deleting ------------------------->>>>>>>>


my_list = ['p','r','o','b','l','e','m']

del my_list[2]

    
print(my_list)


del my_list[1:5]  

print(my_list)


del my_list       

#print(my_list)

