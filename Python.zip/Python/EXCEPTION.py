try:
    whatcolor=input('what colore do you with to know the data of ?')
    if whatcolor in colors:
        coldexx=colore.Index (whatcolor.lower())
        thedate=dates[coldex]
        print ('the date of ',whatcolor,'is:',thedate)
    else:
        print ('color not nfound ,or is not a color')
except NameError as e:
    print 'except  :::' , e




try:
    print ('enter a num')
    number = int(input())
    print ("enter a denmnater")
    deno = int(input())
    ans = number / deno 
    print ans
except:
    print ('cnot divide by zero')
    print ('enter a new den')
    deno = int (input())
    ans = number / deno 
    print ans

try:
    age={"suri":32,"venky":28,"ss":23,"pk":22}
    print (age["suri"])
    print (age["venky"])
    print (age["ss"])
    print (age["pkl"])
except KeyError:
    print("there is a key error")

try:
    a=3
    b=28
    print a+b
except:
    print ("there is a error   c ") 


