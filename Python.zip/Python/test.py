class A():
    name = raw_input('Please enter ur name : ')
    def __init__(self,a, b):
        self.a = a
        self.b = b
    def add(self,a, b):
        print ' my addition is:',self.a + self.b
inst = A(1,2)
inst.add(4,2)

class Arithmetic():
    name = raw_input(' is name' )
    def __init__(self,a, b):
        self.a = a
        self.b = b  
    def add(self, a,b):
        print self.a + self.b
    def sub(self, a,b):
        print a*b
    def div(self, a,b):
        print a/b
    def modulus(self, a,b):
        print a%b 
inst = Arithmetic(4,4)
inst.add(2,2)