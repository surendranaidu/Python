import re

college= 'Sv college of engineering in Tirupati branch mba  surendra Roll no: 14be1e00e4'

obj=re.match(r'(s.*)in(.*)branch(.*)(.*)',college,re.I)


#obj=re.match(r'sv college of',college,re.I)
print obj.group()
print obj.group(1)
print obj.group(2)
print obj.group(3)
print obj.span()
print obj.end()
print obj.groups()



#--------------------------------------------------->>>>>>>

sv = 'Sv college of engineering in Tirupati mba branch surendra Roll no: 14be1e00e4'

obj=re.match(r'sv2 college',sv,re.I)
if obj:
    print 'match is sv college ------->>>>>>',obj.group()
else:
    print "no matching sv college ?"


#------------------gmailmatch--------------->>>>>>>>>>>>>>>>>>>

Email='Surendranaidu10@gmail.com'

obj=re.match(r'.*',Email,re.I)
print '--------email is---------.>>>>>>',obj.group()