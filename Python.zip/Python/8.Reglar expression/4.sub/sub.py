import re

s= 'i am surendra in MBA in finance '


obj=re.sub('finance','software',s,132434)
print obj