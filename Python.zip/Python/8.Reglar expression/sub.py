#!/usr/bin/python
import re

phone = "sriram sriram sriram"

# Delete Python-style comments
num = re.sub('sriram', "Sriram Chowdary", phone, max=0 )

print "Phone Num : ", num

# Remove anything other than digits
num = re.sub(r'\D', "", phone)    
print "Phone Num : ", num