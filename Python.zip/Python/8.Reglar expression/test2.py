import re

#college= 'sv college of engineering in tirupati Surenndranaidu10@gmail.com branch mba Surendra Roll no: 14bf1e00e4'


#obj1= re.search(r'[A-Z][a-z]+\d+\D\w+.\w+',college,re.M)
#print "new obj search is", obj1.group()



#obj2= re.search(r'..............\b',college,re.M)
#print "new obj search is", obj2.group()


#obj3= re.search(r'^.....................',college,re.M)

#print "new obj search is", obj3.group()



#obj= re.search(r'^.*',college)

#print "new obj search is", obj.group()


#obj= re.search(r'.*.m$',college)

#print "new obj search is", obj.group()


a = "ABC12DEF3G56HIJ7"
obj = re.compile(r'([A-Z]+)([0-9]+)',a)

print obj.group()

