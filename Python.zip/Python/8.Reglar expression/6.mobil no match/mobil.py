import re

#mobil='99 85 79 76 47'
phone = '998-579-7647'


#obj=re.match(r'\d{2}\s\d{2}\s\d{2}\s\d{2}\s\d{2}',mobil)
#obj=re.match(r'\(?\d{3}[-)]\d{3}[-]\d{4}',phone)
obj=re.match(r'\d.*\D*',phone)

print obj.group()
