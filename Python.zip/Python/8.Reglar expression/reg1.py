import re

surendrafrinds ='''
sivaram  is 24 years old, and JAGGU aaaa agan is 25 old.
Venky is 23 years old,Anil 22 years old and  his Surendra frinds is 100'''
names = re.search(r'..+\n*',surendrafrinds ,re.I)  #............ ^ doubt
#names = re.search(r'...$',surendrafrinds)................ $ ok tested
#names = re.search(r'[A-Z][a-z]*',surendrafrinds)
#names = re.search(r'\W\d+',surendrafrinds)
#names = re.findall(r'\D+',surendrafrinds)
#names = re.search(r'\d+',surendrafrinds)
#names = re.findall(r'\w\ld',surendrafrinds)

ages = re.findall(r'\d{1,3}',surendrafrinds)

print 'names are :', names.group()

#print ' Age is :', ages

agedict ={}
x = 0
#for eachname in names:
#    agedict[eachname]= ages[x]
#    x+=1
#print
#print(agedict)