import re

a = 'hp gassi pearl gnkwddhcck whwhkhwkhhhfkfhments^^&and 012345 567890 647443837#!&akr'
#print re.search(r'\w+',a).group()
#print re.search(r'\W+',a).group()
#print re.findall(r'\W\d\S*',a)
#print re.search(r'\d+\s\d+\s\d+',a).group()
#print re.search(r'\w+\s\w+',a).group()
#print re.search(r'[a-z]+',a).group()
#print re.findall(r'\Bign\B',a)
#print re.search(r'k\b',a).group()
#print re.search(r'k\b',a).group()
print re.search(r'hp|hindustan pvt ltd',a).group()
#print re.findall(r'pearl|python',a)