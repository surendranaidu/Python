import re
n = ' ganesh sriram chowdary sriram'


#r = re.search(r'\Bsriram\B', n)

r = re.search(r'sriram|chowdary', n)

print 'r is :', r.group()