import re


'''surendra =
Siva is 24 years old, and Jagan is 25 old .
Venky is 23 years old,Anil 22 years old and  his surendra frinds Is 220.
obj=re.findall(r'[A-Z][a-z]*',surendra)
obj1=re.findall(r'[a-z][A-Z]*',surendra)
#object=re.findall(r'\d{1,3}',surendra)
obj2=re.findall(r'[A-Z].*\S',surendra)


print obj
print object
print obj1
print obj2'''


'''import re
print re.findall(r'$.*','surendra')
print re.findall(r'^.*','surendra')
print re.findall(r'\w','http://www.hackerrank.com/')
print re.findall(r'\w','http://www.hackerrank.com/')




import re
#print"---------------->>>>>>", re.findall(r'\w*\D\w+.\w*','surendranaidu10@gmail.com')
print"---------------->>>>>>", re.findall(r'.*','surendranaidu10@reddif.com')
#print"---------------->>>>>>", re.findall(r'\w*\D\w+.\w*','surendranaidu10@gmail.com')'''

Email1="surendra.naidu10@gmail.co.in"
Email2="surendra123@gmail.co.in.gov"
Email3="surendra@yahoo.com"
Email4="surendra123@reddif.com.in"
Email5="surendranaidu@capgmani.in"
Email6="surendran12345@gmail.com"
Email7="surendranaidu10@gmail.org"
Email8="surendranaid@cak.what"
Email9="surendranaidu10@capagemini.com"


mat=re.search(r'(\w+[.\w])*@(\w+[.])*(com$|in$|org$|what$|gov$|co$)',Email4)
#mat=re.search(r'^.*(com$|in$|org$|what$)',Email9)

#mat=re.search(r'\w+.\w+.\w+.(com$|in$)',Email1)

#mat=re.search(r'.*(com$|in$)',Email2)


#mat=re.search(r'.*.$',Email1)
#mat=re.search(r'.*.$',Email1)

print "this is my email id::",mat.group()









