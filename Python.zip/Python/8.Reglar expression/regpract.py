import re

surendrafrinds ='''
Siva is 24 years old, and Jagan is 25 old.
Venky is 23 years old,Anil 22 years old and  his Surendra frinds is 220.
'''
#names = re.findall(r'[A-Ya-z]*',surendrafrinds)
#names = re.findall(r'[A-Y][a-z]?',surendrafrinds)
names = re.findall(r'[A-Y][a-z]+',surendrafrinds)
ages = re.findall(r'\d{1,2}',surendrafrinds)
#names = re.findall(r'\w+',surendrafrinds)
#names = re.findall(r'\W+',surendrafrinds)
#names = re.findall(r',surendrafrinds)


#names = re.findall(r'\w*',surendrafrinds)


print names
print
print ages

'''agedict ={}
x = 0
for eachname in names:
    agedict[eachname]= ages[x]
    x+=1
print
print(agedict)'''