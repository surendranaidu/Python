import re

college= 'Sv college of engineering in Tirupati branch mba Surendra Roll no: 14bf1e00e4'


obj= re.search(r' (surendra)(..*)',college,re.I)
print "new obj search is", obj.group()
print obj.group(2)
print obj.groups()

print "---------------------------------------------->>>>>>>>>>>>>>"

college= 'Sv college of engineering in Tirupati branch mba Surendra Roll no: 14bf1e00e4'






obj=re.search(r'(.*)in(.*) (.*) mba(.*) (\d*\D+..\d...)',college,re.I)
print obj.group()
print obj.group(1)
print obj.group(2)
print obj.groups(),

print obj.span()
print obj.end()
print obj.start()


print" --------------------------------------------------->>>>>>>>>>>"

'''
#!/usr/bin/python

line = "Cats are smarter than dogs";

searchObj = re.search( r'(.*) are (.*?) .*', line, re.M|re.I)

if searchObj:
   print "searchObj.group() : ", searchObj.group()
   print "searchObj.group(1) : ", searchObj.group(1)
   print "searchObj.group(2) : ", searchObj.group(2)
else:
   print "Nothing found!!"

print "------------------------------------>>>>>>>>>>>>>>>> next method"


obj=re.search(r'sv college of engineering',college,re.I)
print obj.group()


k= re.search(r'roll no: 14bf1e00e4',college,re.I)

if k:
    print 'roll no is match',k.group()
else:
    print " no roll number ?"
'''
