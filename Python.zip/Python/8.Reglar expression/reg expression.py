import re

company= "hp Pspdell\n nokia herohondA tata"
obj= re.match('hp',company,re.I)
print 'match is this company----->',obj.group()


obj= re.search("tata", company )


#obj= re.search(".................", company.strip() )
print 'search company is ----->',obj.group()


p="van, mcan ,can , lan ran panc 12,34,56,777,888,9899,09999"

#OJ=re.findall(r"\d{0,3}",OJ)

#print OJ
#Ssuri= re.findall(r'[a-w]c',p)
suri= re.findall('[vmclrp]an',p)
#suri= re.findall('[vmclrp]an',p)
#suri= re.findall('[vmclrp]an',p)

print suri
MYCNT='SURENDRA,PATTIPATI:9985797647'
re.search(r'\w+,\w+:\s+',MYCNT)
print k.group()
