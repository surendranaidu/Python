import re
college="Svce aits crit jntua"
obj=re.match("svce",college,re.I)
if obj:
    print "my college is --->",obj.group()
else:
    print "not there "

obj=re.search("sku",college,re.I)
if obj:
    print 'my univarsity is ========>',obj.group()
else:
    print "not there"


obj=re.search(".........." ,college,re.I)
print'second',obj.group()


