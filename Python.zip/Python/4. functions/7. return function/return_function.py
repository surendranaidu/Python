def ret(a,b):
    print "name is ",a
    print "name is ",b
    print 'sum of', a+b
    return a+b
a=ret(10,20)

def suri(c):
    print 'return is ',c
suri(a)

