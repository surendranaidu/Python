def Add(name, b,c):
    print "name is" , name
    print "name is" , b
    print " is" , c
    print "sum  is" , b+c
Add('suri',10,23)

print " ---------------------2 nd step"

def Add(name, age, id):
    print "name is" , name
    print "Age is" , age
    print "Id  is" , id
    print "sum  is" , 
Add('surendra',22,'e4')