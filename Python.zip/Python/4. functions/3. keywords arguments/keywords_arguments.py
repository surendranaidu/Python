def keyword(name,age):
    print "name is ",name
    print "name is ",age

keyword(age=20,name='surendra')

print "----------------------->>>>>>>>>>"

def keyword(name="suri",age=23): 
    print "name is ",name
    print "name is ",age

keyword(age=20,name='surendra')