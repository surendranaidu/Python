def default(name,age=23):
    print "name is ",name
    print "name is ",age
    return


default(age=20,name='surendra')
default(name='suri')


print "---------------------.>>>>>>>>>>>>>"
 #bet not useing 2nd argument defalt 
 
 
#def default(name ='suri',age):
    #print "name is ",name
    #print "name is ",age
    #return


#default(20)





