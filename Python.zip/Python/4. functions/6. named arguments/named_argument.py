def add(**ibm):
    print "ibm branchs is",ibm

add(ibm='hyd',ibm1='blg',ibm2='ok')


def add(**c):
    print ' C value is : ', c


add(a='one', w23='ok')

