def v_length(a, *b):
    print "a value is " ,a
    print "b values is",b
v_length(1,1,2,3,3,4,4,5,5)



def v_length(dell,*Ibm):

    print "out put is"
    print dell

    for i in Ibm:

        print "b values is------->>>>>>>>>>>>>>",i
    return;
v_length("ATP")
v_length("hyd","bangalore","chenni","delhi")







