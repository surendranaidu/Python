  
#  global values

a= 5
b= 4

def add():   
    print "sum is", a+b
add()


#local

def add():
    print  "a value is",a
    print "name is ", b
a= 10 
b="surendra"
add()