import sys
sys.path.append('C:\\Users\\sriram\\Desktop\\folder\\suri')
import rrr
