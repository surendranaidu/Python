n = 15

# initialize sum and counter
sum = 0
i = 10

while i < n:
    sum = sum + i
    print (i)
    i = i+1   # update counter

# print the sum
print("The sum is", sum)




i = 1
while i < 9:
    print(i)
    i = i+1