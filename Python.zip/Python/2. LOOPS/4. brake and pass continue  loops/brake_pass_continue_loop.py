for i in range(10):
    if i == 5: 
        break

    print i



for i in "surendranaiduchowdary":
    if i =="n": 
        continue
        #break
        pass
    print i,



for i in range(25):
    if i%2==0:
        continue
    print "add numbers is",i

for i in range (100):
    if i % 2==1:
        break
    print "even numbers is ",i

