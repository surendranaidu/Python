'''num = float(input("Enter a number: "))
if num >= 0:
    if num == 0:
        print("Zero")
    else:
        print("Positive number")
else:
    print("Negative number")
'''



print " start"
for i in range(30):
    if i==5:
        pass
    print ",2*", 2*i








