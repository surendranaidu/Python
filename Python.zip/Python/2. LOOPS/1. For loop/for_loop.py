number=[6,5,7,8,4,2,5,4,11]
sum=0
for i in number:
    sum=sum+i
print 'sum is ',sum

print list(range(10))

print list(range(2,8))
print list(range(1,10 ,2))
