number= raw_input("enter a number")
number =input('enter a number')
if number % 2==0:
    print "your number is even",number
else:
    print ("your number is add")