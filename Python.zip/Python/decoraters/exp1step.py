def s(name):
    print "hellohdhdj",name
s("surendranaidu")
k=s
k("nendra")
#p=k
#p("narendra")







def kss(name):
    return "hello",name
suku=kss
print suku("surendra")
r=suku("gasegasga")
print r
