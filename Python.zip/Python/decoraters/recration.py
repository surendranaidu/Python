'''def add(name):
    print "name is",name 
    def sum():
        return 50+50
    return "sume of" ,sum()
sure = add("surendra")
print(sure)'''



def add(name):
    print "hello",name
    def aa():
        return 10+90
    def sub(d,e):
       return d+e
    def mul():
       return 10*100 
    return aa(),sub(5,2),mul()
a=add("surendra naidu")
print a 





'''def kss(name):
    return "hello",name
suku=kss
print suku("surendra")
r=suku("gasegasga")
print r'''
