def sure(name):
    print "hello ",name
    