class surendra():
    def __init__(self,name,sex, address):
       self.name = "name is",name
       self.gendra = sex
       self.address="address is----->",address
will= surendra("sukumar","male" ,"ananthpur")
print will.name
print will.gendra,will.address


class Parent(object):

    def altered(self):
        print "PARENT altered()"

class Child(Parent):

    def altered(self):
        print "CHILD, BEFORE PARENT altered()"
        #super(Child, self).altered()


c = Child()

c.altered()
