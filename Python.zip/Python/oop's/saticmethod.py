class Surendra():
    @classmethod
    def add(self):
        print "add dgileffuhef"
p=Surendra()
p.add()

class Dinesh():
    @staticmethod
    def a():
        print "surendra"
k=Dinesh()
k.a()
    w