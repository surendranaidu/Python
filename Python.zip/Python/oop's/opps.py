class math():
    name="surendranaidu"
    def __init__(self, a,b):
        self.a1 = a 
        self.b2 = b
        self.c3 = 10
    def add(self,m,k):
        print "adding numbers is", m + k + self.c3
        print "callin name calss",math.name
    def sub(self,a,b):
        self.a1=a
        self.b2=b
        print "subsctration is ", self.a1-self.b2
        print " class name is ",math.name
#a= math.add(2,3)
#inst = math(20,40)
#inst1 = math(22,30)
#print dir(math)

inst=math(20,30)
inst1=math(20,50) 

inst.sub(10,5)
inst1.sub(15,8)

