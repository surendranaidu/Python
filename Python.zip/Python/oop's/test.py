
a = 0
print id(0)
print 

#print id(a)