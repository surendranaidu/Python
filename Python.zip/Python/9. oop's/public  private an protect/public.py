class Cup:
    def __init__(self,color,content):
        self.color=color
        self.content=content

    def fill(self, beverage):
        self.beverage = beverage

        print "the colour is::",self.color
        print "the colour is::",self.content
        print "the colour is::",self.beverage
    def empty(self):
        self.content=content


redCup= Cup(s.n)
redCup.fill()
redCup.empty()