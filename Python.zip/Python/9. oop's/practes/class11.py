'''class Arthamatic():
    def add(self,a,b):
        print 'sum is a b', a+b 
    def sub(self,a,b):
        print 'subscraction is ',a-b
inst=Arthamatic()
inst.add(20,30)
inst.sub(50,10)   

print 

class Arthamatic():
    def __init__(self,a,b):
        self.a = a
        self.b = b
    def add(self,a,b):
        print 'add i9s  ',self.a + self.b
    def sub(self,a,b):
        print 'sub i9s  ',a-b
inst=Arthamatic(20,30)
inst.add(10,30)
inst.sub(50,10)   


class Surendra():
    def __init__(self,a, b):
        self.a = a 
        self.b = b 
    def add(self,a, b):
        print ' Surendra Constructer ====> addition is :', self.a + self.b
        print ' Surendra addition is :', a + b
    def sub(self,a, b):
        print 'surendra substraction is:', a - b
inst = Surendra(1,100)
inst.add(2,6)
inst.sub(9,1)
'''





class parent():
    def __init__(self,name,id):
        self.name=name
        self.id=id
    def emp(self ,a,b):
        print 'emp name and address is ',self.name 
        print 'emp name and address is' ,self.id
        print 'sum is ',a+b

class chaild(parent):
    def __init__(self ,name ,id):
        self.name=name
        self.id=id
    def emp(self, a,c):
         print 'chaild  name and ', self.name, self.id
         print 'chaild  name and ', self.id
         print 'a and b division is ', a%c
inst=parent('surendranaidu p','e344')
inst.emp(2,6)
inst=chaild('surendra','e400')
inst.emp(7,6) 
   

print "\n"
   
class Surendra():
    def add(self,a, b):
        print ' Surendra addition is :', a + b
    def sub(self,a, b):
        print 'surendra substraction is:', a - b


class Anjan(Surendra):
    def div(self,a, b):
        print 'Anjan division is :', a / b
    def mul(self,a, b):
        print 'Anjan multiplication is:',a * b
class Sree(Anjan):
    def mod(self,a,b):
        print 'Sree mod:',a%b
    def flor(self,a,b):
        print 'sree floordiv',a//b
    def sub(self,a, b):
        print 'sree substraction is:', a - b
        super(sree ,self) .sub(2,3)
 

inst = Sree()
inst.add(2,6)
inst.sub(9,1)
inst.div(81,9)
inst.mul(9,9)
inst.mod(4,2)
inst.flor(10,4)
