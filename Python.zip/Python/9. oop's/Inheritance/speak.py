import sI4a 

droid=sI4a.android()
massage= droid.dialogGetInput('TTS','What would you like to say?').result
roid.ttsSpeak(massage)