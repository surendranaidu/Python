class father():
    def gradening(self):
        print "i like a gradening"
class mother(father):
    def cooking(self):
        print "i  love cooking"
class child(father,mother):
    def sport(self):
       print "i like cricket"
inst=child()
inst.gradening
inst.cooking
inst.sport