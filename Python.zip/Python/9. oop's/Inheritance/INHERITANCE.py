class vehicle():
    def general_use(self):
        print ('general_use :transporation')
class car(vehicle):
    def __init__(self):
        print ('i am car')
        self.wheels=4
        self.has_root=True
    def specitic_usage(self):
         print ('specitic use commute to work vacation with family')

class motorcycle(vehicle):
    def __init__(self):
        print ('i sm bick')
        self.wheels=2
        self.has_root=True
    def specitic_usage(self):
        print ('specitic use roop road  trip, racing')
c=car()
c.general_use()
c.specitic_usage()
a=motorcycle()
a.general_use()
a.specitic_usage()


class parent():
    def __init__(self,name,age):
        self.name=surendra
        self.age=27

    