class Surendra():
    def add(self,a, b):
        print ' Surendra addition is :', a + b
    def sub(self,a, b):
        print 'surendra substraction is:', a - b
inst = Surendra()
inst.add(2,6)
inst.sub(9,1)

class Anjan():
    def div(self,a, b):
        print 'Anjan division is :', a / b
    def mul(self,a, b):
        print 'Anjan multiplication is:',a * b
x = Anjan()
x.div(81,9)
x.mul(9,9)