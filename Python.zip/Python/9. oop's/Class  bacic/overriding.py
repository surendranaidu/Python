'''

class Surendra():
    def add(self,a, b):
        print ' Surendra addition is :', a + b
    def sub(self,a, b):
        print 'surendra substraction is:', a - b
    def mod(self,a, b ):
        print ' Surendra Modulus is ===>',a % b
class Anjan(Surendra):
    def div(self,a, b):
        print 'Anjan division is :', a / b
    def mul(self,a, b):
        print 'Anjan multiplication is:',a * b
    def mod(self,a, b ):
        print ' Anjan Modulus is ===>',a % b

inst = Anjan()
inst.add(2,2)
inst.sub(8,2)
inst.div(8,2)
inst.mul(9,9)
inst.mod(8,2)

'''


#print "\n over loding::::::---->>>>"

class arthamatic():
    def add(self ,a,b):
        print "sum is ::-->>",a+b
    def add(self ,c,d):
        print "mul is ::-->>",c*d
inst=arthamatic()
inst.add(2,4)

