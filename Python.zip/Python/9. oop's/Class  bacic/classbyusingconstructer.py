class Surendra():
    def __init__(self,a, b):
        self.a = a 
        self.b = b 
    def add(self,a, b):
        print ' Surendra Constructer ====> addition is :', self.a + self.b
        print ' Surendra addition is :', a + b
    def sub(self,a, b):
        print 'surendra substraction is:', a - b
inst = Surendra(1,100)
inst.add(2,6)
inst.sub(9,1)






class parent():

    def __init__(self,name,eid,address):
        self.name=name
        self.eid=eid
        self.address=address
    def age(self ,a):
        print 'name is', self.name
        print 'employee id',self.eid
        print 'address in',self.address
        print 'age is ',a
class colleges(parent):
    def __init__(self,college,branch,agregtion):
        self.college=college
        self.branch=branch
        self.agregtion=agregtion
    def place(self,pls):
        print 'college and branch agragation ',self.college,self.branch,self.agregtion
        print 'palase is ', pls


i=parent('surendra','e4','Atp')
i.age(22)
i=colleges('sv college','Mba','75%')
i.place('Tirupati')






class over():
    def __init__(self,a,b):
        self.a=a
        self.b=b
        print ' sume of a and b is',a+b
    def sum(self,a,b):
        print'sume is a and b',a+b
class over2(over):
    def __init__(self,a,b):
        print 'sume is ',a+b
    def sum(self,a,b):
        print 'sume is',a+b


inst=over(2,3)
inst.sum(2,3)
inst=over2(2,8)
inst.sum(2,5)