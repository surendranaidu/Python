
print "\n 1.inheritance----------->>>>>>"

class father():
    def gradening(self):
        print "i like a gradening"
class mother(father):
    def cooking(self):
        print "i  love cooking"
class child(mother):
    def sport(self):
       print "i like cricket"
inst=child()
inst.gradening()
inst.cooking()
inst.sport()








print "\n 2.multiple inheritance--------->>>>>"

class father():
    def gradening(self):
        print "i like a gradening"
class mother():
    def cooking(self):
        print "i  love cooking"
class child(father,mother):
    def sport(self):
       print "i like cricket"
inst=child()
inst.gradening()
inst.cooking()
inst.sport()






print "\n 3.multileval inheritance-----:::>>>"

class father():
    def gradening(self,a,b):

        print "i like a gradening"
        print 'sum is ',a+b
class mother(father):
    def cooking(self,a,b):
        print "i  love cooking"
        print 'sum is ',a*b
class child(mother):
    def sport(self):
       print "i like cricket"
inst=child()
inst.gradening(2,4)
inst.cooking(5,6)
inst.sport()



print "\n 4. overriding::::--------**>>>"

class arthamatic(object):
    def add(self ,a,b):
        print "sum is ::-->>",a+b
    def mul(self ,a,b):
        print "mul is ::-->>",a*b

class match(arthamatic):
    def div(sef ,a,b):
        print "div is ::-->>",a%b 
    def sub(self ,a,b):
        print "sub is ::-->>",a-b
    def add(self ,a,b):
        print "sum is  match is::-->>",a+b
        super(match,self).add(4,6)
inst=match()
inst.add(2,4)
inst.div(6,8)
inst.sub(10,5)
inst.mul(2,4)


print "\n over loding::::::---->>>>"

class arthamatic():
    def add(self ,a,b):
        print "sum is ::-->>",a+b
    def add(self ,c,d):
        print "mul is ::-->>",c*d
inst=arthamatic()
inst.add(2,4)




