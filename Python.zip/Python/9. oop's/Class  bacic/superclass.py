class Surendra(object):
    def add(self,a, b):
        print ' Surendra addition is :', a + b

class Anjan(Surendra):
    def add(self,a, b):
        print ' Anjan addition is :', a + b
        super(Anjan,self).add(5,5)

inst = Anjan()
inst.add(3,9)





'''print "#-----------------------------------------------"

class Parent(object):

    def altered(self):
        print "PARENT altered()"

class Child(Parent):

    def altered(self):

        print "CHILD, BEFORE PARENT altered()"
        super(Child, self).altered()


c = Child()

c.altered()'''





'''
class Surendra():
    def add(self,a, b):
        print ' Surendra addition is :', a + b
inst = Surendra()
inst.add(9,6)

class Anjan(object,Surendra):
    def add(self,a, b):
        print ' Anjan addition is :', a + b
        #super(Anjan,self).add(5,5)

inst = Anjan()
inst.add(3,9)
'''



