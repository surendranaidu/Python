'''class surendra():
    def __init__(self,name,sex, address):
       self.name = "name is",name
       self.sex = sex
       self.address="address is----->",address
will= surendra("sukumar","male" ,"ananthpur")
print will.name
print will.sex,will.address

class arthimatic():
    def __init__(self,A,B):
        self.A=A
        self.B=B
a=arthimatic(10,20)
print a.A+a.B
'''
class employee:
    empcount=0
    def __init__(self,name,salary):
        self.name = name
        self.salary=salary
        employee.empcount+=1
    #def displaycount(self):
        #print "total emp%d",employee.empcount
    def displayemployee(self):
        print self.name
        print self.salary
emp1=employee("surendra",20000)
emp1.displayemployee()
emp1=employee("narendra",222222)
emp1.displayemployee()
print 'total emp%',employee.empcount


class employee:
    def __init__(self,name,salary):
        self.name = name
        self.salary=salary





