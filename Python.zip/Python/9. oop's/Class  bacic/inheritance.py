class Surendra():
    def add(self,a, b):
        print ' Surendra addition is :', a + b
    def sub(self,a, b):
        print 'surendra substraction is:', a - b


class Anjan(Surendra):
    def div(self,a, b):
        print 'Anjan division is :', a / b
    def mul(self,a, b):
        print 'Anjan multiplication is:',a * b
class Sree(Surendra,Anjan):
    def mod(self,a,b):
        print 'Sree mod:',a%b
    def flor(self,a,b):
        print 'sree floordiv',a//b

inst = Sree()
inst.add(2,6)
inst.sub(9,1)
inst.div(81,9)
inst.mul(9,9)
inst.mod(4,2)
inst.flor(10,4)
