import pdb

n = 'sriram'

print 'name is :', n

pdb.set_trace()

n = 123

print 'name is :', n

