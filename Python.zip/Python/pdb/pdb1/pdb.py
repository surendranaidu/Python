import pdb

def sure(x,y):
    y = y**2
    x *=  2
    z = x+y
    return z
x =50
y =60
z =50
n =1000
pdb.set_trace()
sure (5,10)
print 'z='+ str(z)
n = sure (2,3)
print 'n=' + str(n)