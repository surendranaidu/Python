import pdb

def sure(name,age):
    print "name is",name
    print "age is", age
pdb.set_trace()
sure(name="surendra",age= 25)
