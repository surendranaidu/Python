import pdb

def sure(x,y):
    y = y**2
    x *=  2
    z = x+y
    return z
x =50
y =60
z =50
n =10

sure(5,10)
pdb.set_trace()
print 'z='+ str(z)
n = sure (12,10)
print 'n=' + str(n)