'''import pdb

n=12

#print n
nn = 'surendra'
pdb.set_trace()

#print nn'''


import pdb

n = 'sriram'

print 'name is :', n

pdb.set_trace()

nn = 123

print 'name is :' + n

