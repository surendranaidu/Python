from add import add,sub
add(1,2)
sub(10,5)