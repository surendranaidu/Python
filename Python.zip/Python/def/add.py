a = 'sriram'
print a
def add(a,b):
    pass
    print "total sum of values:",a+b
add(4,5)

def sub(a,b):
    pass
    print "sum of values :",a-b
sub(10,5)
