
#####join###################
a =''
b ='chowdary'
c= 'aa'
print "a sting join ",a.join(b),"c join in c ",b.join(c)


#find ;;;;;;;;;;;;;;

k= 'surendrsnaidu'
p='i'
c= 'bangalore'
m='g'
print "find is",k.find(p)
print 'find g is ',c.find(m,2,6)


#index''''''''''''

str1 = "this is string example....wow!!!";
str2 = "exam";

print str1.index(str2)
print str1.index(str2, 9)
print str1.index(str2, )

#replace..............

str = "this is string example....wow!!! this is really string";
print str.replace("is", "was")
print str.replace("is", "was",1 )

#count'''''''''''
suri = "this is string example....wow","!!! this is really string";
sub='i';
print str.count(sub);

############# islower ,, is upper #################


str = "this is string example....ow!!! this is really string";
str='Surendrachowdarey'
print str.islower()
print str.isupper()
#print str.whitespace()

print str.title()

#'''''''' title ''''''''
s= 'surendra naidu chowdary sv college'
print s.title()

#'''''''''''strip'''''''''''

a ="   surendra surendra re  "
print a.strip()
print a.rstrip()
b=a.lstrip()
print[b]



#*****SLICE OPERATION*******


slice = "i am surendra naidu atp"

print slice[2:]
print slice[:10]
print slice[1:16]


##### update****************

print slice+"Andhrapradesh"

print slice[:14]+"chowdary"



