print "\n sting format"

a='surendra'
b='1be4'

print "name is: {0},and id is: {1} ".format(a,b)



print "\n 2.format using pyramid"

for i in range(1,88,2):
    print '{:^1{}}'.format('^'*i,10)




a = 'surendra{}'

#print 'format is {1},:', a.format('sriram','chowdary','NAIDU')
print 'format is: {}'. format(a),a.format('suri')


'''data = ("John", "Doe", 53.44)
format_string = "Hello"

print(format_string % data)'''
