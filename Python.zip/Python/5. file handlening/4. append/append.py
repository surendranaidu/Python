with open("a.txt",'a') as fa:
    fa.write('surendra23333')