import os
os.rename('a.txt','surendra.txt')