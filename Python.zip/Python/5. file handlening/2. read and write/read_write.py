b=open('new.txt','r+')
#b.write('a')
b.write('uuu')
print b.read()
'''
c=open('a.txt','w+')

c.write('surendranaidu2222')'''





