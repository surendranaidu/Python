import os
os.remove('a.txt')