with open ('b.txt','w') as fw:
    fw.write('slcfjhcbvcjhd')
    




'''
with open('a.txt','a+') as fr:
    #print fr.read()
    print fr.write('surendrachowdary')
	'''