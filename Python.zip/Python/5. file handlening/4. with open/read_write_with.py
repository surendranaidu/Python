
with open('a.txt', 'r') as fh, open('b_write.txt', 'r') as fhw:
    print fh

    for line in fh:
        print 'line is :', line

    for line in fhw:
        print 'line write is :', line

print '----------->>>>',fh.read()
fh.close()