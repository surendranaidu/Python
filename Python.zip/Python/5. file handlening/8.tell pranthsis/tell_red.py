a=open('mm.txt','r')
print a.read()
b=a.tell()
print b