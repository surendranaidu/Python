a= open ('t.txt','r')
b=a.read()
print b
print len(b.split())  #WORD COUNT LEN AND SPLIT()
print len (b)         # CHARATACTER COUNT USING LEN ONLY




'''
print len(a.split()) 
'''

'''
if b == "surendra":
    print 'ok'
else:
    print "not ok"
'''