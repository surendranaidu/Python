a=open('test.txt','r')
#print a.read()
#print a.readline()
print a.readlines()