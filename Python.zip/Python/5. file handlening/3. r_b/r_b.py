'''rb=open('rb.txt','rb')
print rb.read()'''


with open ('rb.txt','r') as fr:
    print fr.read()